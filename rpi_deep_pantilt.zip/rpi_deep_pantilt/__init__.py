# -*- coding: utf-8 -*-

"""Top-level package for Raspberry Pi Deep PanTilt."""

__author__ = """Leigh Johnson"""
__email__ = 'hi@leighjohnson.me'
__version__ = '1.1.0'
